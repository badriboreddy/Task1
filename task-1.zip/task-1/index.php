<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width-device-width,
    initial-scale=1.0">
    <title>BIKE BUDDY</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
        <a href="#" class="logo">Bike Buddy</a>

        <ul class="navbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="bikes.php">Bikes</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="terms.php">Terms</a></li>
            <li><a href="signup.php">Sign In</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
</ul>
<a href="bikes.php" class="book">Book Bike</a>
</header>
<section class="home">
    <div class="text">
        <h1>Looking for a bike</h1>
        <p>Going for a vacation.No Bike!.Want to rent a bike ?</p>
        <div class="store">
            <img src="playstore.jpg" alt="">
</div>
</div>
<div class="image">
    <img src="bike.png" alt="">
</div>
</section>   
</body>
</html>